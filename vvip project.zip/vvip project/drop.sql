drop table claim_answers;
drop table question_details;

drop table transaction;

drop table account;

drop table claim;

drop table policy_details;


drop table policy;


drop table user_role;