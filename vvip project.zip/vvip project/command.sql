create table user_role(user_name varchar2(20) primary key,password varchar2(12),role_code varchar2(10));

insert into user_role values('admin','admin','admin');

insert into user_role values('kush','pass','agent');

insert into user_role values('vivek','pass','insured');

insert into user_role values('deepak','pass','insured');

insert into user_role values('vamsi','pass','insured');




create table policy(policy_number number(10) primary key,policy_premium number(8,2));


insert into policy values(1001,500000);
insert into policy values(1002,800000);

insert into policy values(1003,550000);
insert into policy values(1004,806000);



create table policy_details(questionid varchar2(15),
policy_number number(10) references policy(policy_number));

insert into policy_details values('BU01',1001);
insert into policy_details values('RES01',1002);
insert into policy_details values('APP01',1003);
insert into policy_details values('GM01',1004);


create table claim(claim_number number(10) primary key,claim_reason varchar2(30),accident_location_street varchar2(40),
accident_city varchar2(30),accident_state varchar2(30),accident_zip number(6),claim_type varchar2(30),policy_number number(10) references policy(policy_number));

create sequence claim_sequence start with 9001;

create table account(account_number number(10) primary key,user_name varchar2(20) references user_role(user_name),agent_name varchar2(20));
create sequence account_seq start with 2001;

insert into account values(account_seq.nextval,'vivek','kush');
insert into account values(account_seq.nextval,'deepak','kush');
insert into account values(account_seq.nextval,'vamsi','kush');

create table transaction(transaction_id number(10) primary key,policy_number number(10) references policy(policy_number),account_number number(10) references account(account_number));
create sequence transaction_seq start with 7001;

insert into transaction values(transaction_seq.nextval,1001,2002);
insert into transaction values(transaction_seq.nextval,1002,2003);
insert into transaction values(transaction_seq.nextval,1003,2002);
insert into transaction values(transaction_seq.nextval,1004,2001);
insert into transaction values(transaction_seq.nextval,1001,2003);


create table question_details(questionid varchar2(15),question varchar2(50),answer1 varchar2(50),answe2 varchar2(50),answer3 varchar2(50));








create table claim_answers(claim_number number(10) references claim(claim_number),policy_number number(10) references policy(policy_number),account_number number(10) references account(account_number),questionid varchar2(15), question varchar2(50),answer varchar2(50));


commit;