package com.cg.exception;

public class OCRException  extends Exception{
	
	public OCRException()
	{
		super();
		
	}

	public OCRException(String message)
	{
		super(message);
		
	}

}
