package com.cg.entity;

public class getQuestions {

	
	private String questionId;
	
	private String question;
	
	private String answer;

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getQuestionId() {
		return questionId;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public getQuestions(String questionId, String question,String answer) {
		super();
		this.answer=answer;
		this.questionId = questionId;
		this.question = question;
	}

	public getQuestions() {
		super();
	}
	
	
}
