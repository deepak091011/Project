package com.cg.entity;



public class PolicyDetails {



	private int policy_details_id;
	


	private String questionId;
	
	
	private int policyNumber;

	public PolicyDetails() {
		super();
	}

	public int getPolicy_details_id() {
		return policy_details_id;
	}

	public void setPolicy_details_id(int policy_details_id) {
		this.policy_details_id = policy_details_id;
	}

	public String getQuestionId() {
		return questionId;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

	public int getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(int policyNumber) {
		this.policyNumber = policyNumber;
	}

	
}
