package com.cg.entity;

import java.util.ArrayList;
import java.util.List;

public class Account {


	private int accountNumber;

	private String userName;

	private String agent;

	private List<Transaction> emp = new ArrayList<Transaction>();
	
	
	public Account(int accountNumber, String userName, String agent) {
		super();
		this.accountNumber = accountNumber;
		this.userName = userName;
		this.agent = agent;
	}

	public Account() {
		super();
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAgent() {
		return agent;
	}

	public void setAgent(String agent) {
		this.agent = agent;
	}
	
}
