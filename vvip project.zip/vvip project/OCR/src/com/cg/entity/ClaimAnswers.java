package com.cg.entity;

public class ClaimAnswers {

	private int	 claimNumber;
	
	private int policyNumber;
	
	private int account_number;
	
	private String questionId;
	
	private String question;
	
	private String answer;

	

	public int getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(int claimNumber) {
		this.claimNumber = claimNumber;
	}

	public int getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(int policyNumber) {
		this.policyNumber = policyNumber;
	}

	public int getAccount_number() {
		return account_number;
	}

	public void setAccount_number(int account_number) {
		this.account_number = account_number;
	}

	public String getQuestionId() {
		return questionId;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public ClaimAnswers(int claimNumber, int policyNumber, int account_number, String questionId, String question,
			String answer) {
		super();
		this.claimNumber = claimNumber;
		this.policyNumber = policyNumber;
		this.account_number = account_number;
		this.questionId = questionId;
		this.question = question;
		this.answer = answer;
	}

	public ClaimAnswers() {
		super();
	}
	
	
}
