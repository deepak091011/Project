package com.cg.entity;

import java.util.ArrayList;
import java.util.List;


public class Policy {

	
	private int policyNumber;
	

	


	private double policyPremium;


	public Policy(int policyNumber, double policyPremium) {
		super();
		this.policyNumber = policyNumber;
		
		this.policyPremium = policyPremium;
	}

	public Policy() {
		super();
	}

	public int getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(int policyNumber) {
		this.policyNumber = policyNumber;
	}

	public double getPolicyPremium() {
		return policyPremium;
	}

	public void setPolicyPremium(double policyPremium) {
		this.policyPremium = policyPremium;
	}
	
}
