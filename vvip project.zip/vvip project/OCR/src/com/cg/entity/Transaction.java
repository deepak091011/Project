package com.cg.entity;




public class Transaction {


	private int transaction_id;
	
	
	

	private int policy_number;
	

	
	private int account_number;
	
	

	public Transaction() {
		super();
	}

	public int getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}

	public int getPolicy_number() {
		return policy_number;
	}

	public void setPolicy_number(int policy_number) {
		this.policy_number = policy_number;
	}

	public int getAccount_number() {
		return account_number;
	}

	public void setAccount_number(int account_number) {
		this.account_number = account_number;
	}

	
	
	
}
