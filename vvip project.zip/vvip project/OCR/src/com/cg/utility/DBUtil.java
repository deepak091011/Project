package com.cg.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.cg.dao.OCRDaoImpl;


public class DBUtil {
	final static Logger logger = LogManager.getLogger(DBUtil.class);

	public static Connection getConnection() throws ClassNotFoundException, SQLException
	{	
		String className="oracle.jdbc.driver.OracleDriver";
		String username="System";
		String password="oracle";
		String url="jdbc:oracle:thin:@192.168.0.182:1521:XE"; //protocol:sub-protocol:type of driver:IP address:port number:type of edition
		Class.forName(className);
		logger.info("Getting Connection");
		Connection conn = DriverManager.getConnection(url,username,password);
		
		return conn;

	}
}
