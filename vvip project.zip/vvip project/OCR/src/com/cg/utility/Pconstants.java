package com.cg.utility;

public interface Pconstants {
	
	static final String errorPage = "ErrorPage.jsp";
	

}
