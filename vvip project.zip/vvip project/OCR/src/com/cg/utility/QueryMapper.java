package com.cg.utility;

public interface QueryMapper {

	static final String validateUserQuery = "select role_code from user_role where user_name=? and password=?";

	static final String insertUserQuery = "insert into user_role values(?,?,?)";

	static final String insertClaimQuery = "insert into claim values(claim_sequence.currval,?,?,?,?,?,?,?)";

	static final String addTransactionQuery = "insert into transaction values(transaction_seq.nextval,?,?)";

	static final String getPfromClaimQuery1 = "select distinct(policy_number),claim_number from claim_answers";

	static final String getPfromClaimQuery2 = "select distinct(policy_number),claim_number from claim_answers where account_number =?";

	static final String getClaimAnswerQuery = "select * from claim_answers where policy_number=? and claim_number=?";

	static final String getClaimQuery = "select * from claim where policy_number=? and claim_number=?";

	static final String getQidQuery = "select distinct(q.questionid),q.question from policy p,policy_details pd,question_details q where p.policy_number=pd.policy_number and pd.questionid=q.questionid and p.policy_number=?";

	static final String claimAnswerInsQuery = "insert into claim_answers values(?,?,?,?,?,?)";

	static final String getAnswerQuery = "select answer from question_details where questionid=?";

	//static final String getQaQuery = "select q.questionid,q.question,q.answer1,q.answe2,q.answer3 from policy p,policy_details pd,question_details q where p.policy_number=pd.policy_number and pd.questionid=q.questionid and q.questionid=?";
	
	static final String getQaQuery = "select q.questionid,q.question,q.answer1,q.answe2,q.answer3 from question_details q where q.questionid=?";

	static final String getAccDetailsInsuredQuery = "select t.account_number from transaction t,policy p,account a where p.policy_number=t.policy_number and a.account_number=t.account_number and a.user_name=?";

	static final String getAccDetailsAgentQuery = "select t.account_number from transaction t,policy p,account a where p.policy_number=t.policy_number and a.account_number=t.account_number and a.agent_name=?";

	static final String getAccDetailsAdminQuery = "select t.account_number from transaction t,policy p,account a where p.policy_number=t.policy_number and a.account_number=t.account_number";

	static final String getPolicyDetailsInsuredQuery = "select t.account_number,t.policy_number,p.policy_premium from transaction t,policy p,account a where p.policy_number=t.policy_number and a.account_number=t.account_number and a.user_name=?";

	static final String getPolicyDetailsAgentQuery = "select t.account_number,t.policy_number,p.policy_premium from transaction t,policy p,account a where p.policy_number=t.policy_number and a.account_number=t.account_number and a.agent_name=?";

	static final String getPolicyDetailsAdminQuery = "select t.account_number,t.policy_number,p.policy_premium from transaction t,policy p,account a where p.policy_number=t.policy_number and a.account_number=t.account_number ";

	static final String createUserGetSeq = "insert into account values(account_seq.nextval,?,?)";

}
