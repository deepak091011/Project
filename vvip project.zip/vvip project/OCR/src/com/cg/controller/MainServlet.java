package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.cg.entity.Claim;
import com.cg.entity.ClaimAnswers;
import com.cg.entity.Policy;
import com.cg.entity.QuestionDetails;
import com.cg.entity.UserRole;
import com.cg.entity.getQuestions;
import com.cg.exception.OCRException;
import com.cg.service.IOCRService;
import com.cg.service.OCRServiceImpl;
import com.cg.utility.Pconstants;

/**
 * Servlet implementation class MainServlet
 */
@WebServlet("*.obj")
public class MainServlet extends HttpServlet {

	final static Logger logger = LogManager.getLogger(MainServlet.class);

	String username = "";
	String password = "";
	String rollcode = "";
	IOCRService service = new OCRServiceImpl();

	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MainServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String path = request.getServletPath().trim();
		String resource = "";
		switch (path) {
		case "/newclaim.obj":
			try {
				logger.info("Inside new Claimr");
				int policy_number = Integer.parseInt(request.getParameter("policy_number"));
				int account_number = Integer.parseInt(request.getParameter("account_number"));
				request.getSession().setAttribute("policynumber", policy_number);
				request.getSession().setAttribute("accountnumber", account_number);
				resource = "claimCreation.jsp";
				service.addTransaction(policy_number, account_number);
			} catch (Exception e) {
				String errorMessage = "Claim Creation Failed";
				request.setAttribute("errorMessage", errorMessage);
				resource = Pconstants.errorPage;
			}

			break;

		case "/viewClaimReport.obj":
			try {
				int claimPolicyNumber = Integer.parseInt(request.getParameter("policy_no"));
				int claimIdNumber = Integer.parseInt(request.getParameter("claim_no"));
				String claimReportUsername = (String) request.getSession().getAttribute("username");
				List<Claim> allClaims = service.getClaim(claimPolicyNumber, claimIdNumber);
				List<ClaimAnswers> allClaimAnswers = service.getClaimAnswer(claimPolicyNumber, claimIdNumber);
				request.getSession().setAttribute("allClaims", allClaims);
				request.getSession().setAttribute("allClaimAnswers", allClaimAnswers);
				resource = "ReportGeneration.jsp";
			} catch (Exception e) {
				String errorMessage = "Internal Error Occured";
				request.setAttribute("errorMessage", errorMessage);
				resource = Pconstants.errorPage;
			}

			break;
		}

		RequestDispatcher rd = request.getRequestDispatcher(resource);
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// doGet(request, response);

		String path = request.getServletPath().trim();
		String resource = "";
		switch (path) {
		case "/login.obj":
			try {
				username = (String) request.getParameter("username");
				password = (String) request.getParameter("password");
				logger.info("Inside Login");
				rollcode = service.validateUserLogin(username, password);
				if (rollcode.isEmpty()) {
					logger.debug("User object is null");
					throw new Exception();
				}
				request.getSession().setAttribute("username", username);
				request.getSession().setAttribute("rollcode", rollcode);
				resource = "RequiredButtons.jsp";
			} catch (Exception e) {
				logger.error("Login Error");
				String errorMessage = "Login Failed";
				request.setAttribute("errorMessage", errorMessage);
				resource = Pconstants.errorPage;
			}
			break;

		case "/logout.obj":
			// request.getSession().invalidate();
			request.getSession(false);
			resource = "index.jsp";
			break;
		case "/usercreation.obj":
			try {
				UserRole usr = new UserRole();
				usr.setUserName((String) request.getParameter("username"));
				usr.setPassword((String) request.getParameter("password"));
				usr.setRoleCode((String) request.getParameter("rollcode"));
				boolean x = service.createUser(usr);
				if (x == false) {
					logger.debug("User object is null");
					throw new Exception();
				}
				request.setAttribute("creationvalue", x);
				resource = "Success.jsp";
			} catch (Exception e) {
				String errorMessage = "Creating user Failed";
				logger.error(errorMessage);
				request.setAttribute("errorMessage", errorMessage);
				resource = Pconstants.errorPage;
			}
			break;

		case "/getpolicy.obj":
			try {
				username = (String) request.getParameter("username");

				rollcode = (String) request.getParameter("rollcode");

				request.setAttribute("username", username);

				List<Policy> list = service.getPolicies(rollcode, username);
				request.setAttribute("policyvalues", list);
				List<Integer> list2 = service.getAccountNumber(rollcode, username);
				request.setAttribute("accountvalues", list2);
				if (list == null || list2 == null) {
					logger.debug("policy functions returning null");
					throw new Exception();
				}
				resource = "allPolicies.jsp";
			} catch (Exception e) {
				String errorMessage = "Internal Error Occured";
				logger.error(errorMessage);
				request.setAttribute("errorMessage", errorMessage);
				resource = Pconstants.errorPage;
			}
			break;

		case "/questionCheck.obj":
			try {
				int claimiid = (Integer) request.getSession().getAttribute("claimId");
				int policyno = (Integer) request.getSession().getAttribute("policynumber");
				int accountno = (Integer) request.getSession().getAttribute("accountnumber");
				List<getQuestions> qid = service.getQid(policyno);
				List<String> ans = new ArrayList<String>();
				List<QuestionDetails> check = (List<QuestionDetails>) request.getSession().getAttribute("questions");
				String questionId = qid.get(0).getQuestionId();
				for (QuestionDetails y : check) {
					ans.add(request.getParameter(y.getQuestion()));
					boolean hello = service.createClaimAnswer(claimiid, policyno, accountno, questionId,
							y.getQuestion(), request.getParameter(y.getQuestion()));
				}
				if (qid == null || ans == null || check == null) {
					logger.debug("Objects return null");
					throw new Exception();
				}
				request.setAttribute("claim_number", claimiid);
				resource = "Success1.jsp";
			} catch (Exception e) {
				String errorMessage = "Internal Error Occured";
				logger.error(errorMessage);
				request.setAttribute("errorMessage", errorMessage);
				resource = Pconstants.errorPage;
			}
			break;

		case "/showAllClaims.obj":
			try {
				List<ClaimAnswers> listClaim = service.getPolicyNumberFromClaim();
				if (listClaim == null) {
					logger.debug("Claim list is null");
					throw new Exception();
				}
				request.getSession().setAttribute("listClaim", listClaim);
				resource = "showAllClaims.jsp";
			} catch (Exception e) {
				String errorMessage = "Internal Error Occured";
				logger.error(errorMessage);
				request.setAttribute("errorMessage", errorMessage);
				resource = Pconstants.errorPage;
			}
			break;

		case "/viewAllClaims.obj":
			try {
				List<ClaimAnswers> listClaim1 = service.getPolicyNumberFromClaim();
				if (listClaim1 == null) {
					logger.debug("Claim list is null");
					throw new Exception();
				}
				request.getSession().setAttribute("listClaim1", listClaim1);
				resource = "viewAllClaims.jsp";
			} catch (Exception e) {
				String errorMessage = "Internal Error Occured";
				logger.error(errorMessage);
				request.setAttribute("errorMessage", errorMessage);
				resource = Pconstants.errorPage;
			}
			break;

		case "/viewAllClaimsForNonAdmins.obj":
			try {
				String username = (String) request.getParameter("username");
				String rollCode = (String) request.getParameter("rollcode");
				List<ClaimAnswers> listClaimNonAdmin = service.getPolicyNumberFromClaim(rollCode, username);
				if (listClaimNonAdmin == null) {
					logger.debug("nonAdmin list is null");
					throw new Exception();
				}

				request.getSession().setAttribute("listClaimNonAdmin", listClaimNonAdmin);
				resource = "viewAllClaimsForNonAdmins.jsp";
			} catch (Exception e) {
				String errorMessage = "Internal Error Occured";
				logger.error(errorMessage);
				request.setAttribute("errorMessage", errorMessage);
				resource = Pconstants.errorPage;
			}

			break;

		case "/viewClaimReport.obj":
			try {
				int claimPolicyNumber = (Integer) request.getSession().getAttribute("policynumber");
				int claimIdNumber = (Integer) request.getSession().getAttribute("claimId");
				String claimReportUsername = (String) request.getSession().getAttribute("username");
				List<Claim> allClaims = service.getClaim(claimPolicyNumber, claimIdNumber);
				List<ClaimAnswers> allClaimAnswers = service.getClaimAnswer(claimPolicyNumber, claimIdNumber);
				request.getSession().setAttribute("allClaims", allClaims);
				request.getSession().setAttribute("allClaimAnswers", allClaimAnswers);
				if (allClaims == null || allClaimAnswers == null) {
					logger.debug("Claim list is null");
					throw new Exception();
				}
				resource = "ReportGeneration.jsp";
			} catch (Exception e) {
				String errorMessage = "Internal Error Occured";
				logger.error(errorMessage);
				request.setAttribute("errorMessage", errorMessage);
				resource = Pconstants.errorPage;
			}
			break;

		case "/claimcreation.obj":

			try {
				Claim claim = new Claim();
				claim.setClaimReason((String) request.getParameter("claimreason"));
				claim.setAccidentLocationStreet((String) request.getParameter("accidentlocationstreet"));
				claim.setAccidentCity((String) request.getParameter("accidentcity"));
				claim.setAccidentState((String) request.getParameter("accidentstate"));
				claim.setAccidentZip(Integer.parseInt((String) request.getParameter("zipcode"))); // get
																									// from
																									// request
																									// remainigng
				claim.setClaimType((String) request.getParameter("claimtype"));
				int val = (Integer) request.getSession().getAttribute("policynumber");
				claim.setPolicy_number(val);
				int claim_id = service.addClaim(claim);
				request.getSession().setAttribute("claimId", claim_id);
				int p = (Integer) request.getSession().getAttribute("policynumber");
				List<getQuestions> queId = service.getQid(p); // To get the
																// question
																// id;
				List<QuestionDetails> listQues = service.getQA(queId.get(0).getQuestionId());
				request.getSession().setAttribute("questions", listQues);

				if (listQues == null) {
					logger.debug("Question List is null");
					throw new Exception();
				}

				resource = "showQuestions.jsp";
			} catch (Exception e) {
				String errorMessage = "Internal Error Occured";
				logger.error(errorMessage);
				request.setAttribute("errorMessage", errorMessage);
				resource = Pconstants.errorPage;
			}
			break;
		}
		RequestDispatcher rd = request.getRequestDispatcher(resource);
		rd.forward(request, response);
	}
}
