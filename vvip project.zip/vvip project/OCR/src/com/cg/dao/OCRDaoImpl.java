package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.cg.controller.MainServlet;
import com.cg.entity.Claim;
import com.cg.entity.ClaimAnswers;
import com.cg.entity.Policy;
import com.cg.entity.QuestionDetails;
import com.cg.entity.UserRole;
import com.cg.entity.getQuestions;
import com.cg.exception.OCRException;
import com.cg.utility.DBUtil;
import com.cg.utility.QueryMapper;

public class OCRDaoImpl implements IOCRDao {

	String result = "";
	int id = 0;

	final static Logger logger = LogManager.getLogger(OCRDaoImpl.class);

	@Override
	public String validateUserLogin(String username, String password) throws OCRException {

		logger.info("Validate Login Called");
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.validateUserQuery);
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			ResultSet rst = pstmt.executeQuery();

			if (rst.next()) {
				return rst.getString("role_code");
			}
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e.getMessage());
			throw new OCRException(e.getMessage());
		}
		return null;

	}

	@Override
	public boolean createUser(UserRole userobj) throws OCRException {

		logger.info("Create user called");
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.insertUserQuery);
			pstmt.setString(1, userobj.getUserName());
			pstmt.setString(2, userobj.getPassword());
			pstmt.setString(3, userobj.getRoleCode());
			int result = pstmt.executeUpdate();

			if (userobj.getRoleCode().equals("insured")) {
				pstmt = con.prepareStatement(QueryMapper.createUserGetSeq);
				pstmt.setString(1, userobj.getUserName());
				pstmt.setString(2, "");
			} else if (userobj.getRoleCode().equals("agent")) {
				pstmt = con.prepareStatement(QueryMapper.createUserGetSeq);
				pstmt.setString(2, userobj.getUserName());
				pstmt.setString(1, "");
			}
			pstmt.executeUpdate();
			con.commit();
			con.close();
			if (result == 1)
				return true;
		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e.getMessage());
			throw new OCRException(e.getMessage());
		}

		return false;
	}

	@Override
	public int addClaim(Claim claim) throws OCRException {
		String getClaimNumberQuery = "select claim_sequence.nextval from dual";
		int claimId = 0;
		Connection con = null;
		logger.info("Add Claim is Called");

		try {
			con = DBUtil.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.insertClaimQuery);
			PreparedStatement pstmt2 = con.prepareStatement(getClaimNumberQuery);

			ResultSet rst1 = pstmt2.executeQuery();
			if (rst1.next()) {
				claimId = rst1.getInt(1);
			}

			pstmt.setString(1, claim.getClaimReason());
			pstmt.setString(2, claim.getAccidentLocationStreet());
			pstmt.setString(3, claim.getAccidentCity());
			pstmt.setString(4, claim.getAccidentState());
			pstmt.setInt(5, claim.getAccidentZip());
			pstmt.setString(6, claim.getClaimType());
			pstmt.setInt(7, claim.getPolicy_number());
			id = pstmt.executeUpdate();
			con.close();

		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e.getMessage());
			throw new OCRException(e.getMessage());
		}

		return claimId;
	}

	@Override
	public List<Policy> getPolicies(String rollcode, String username) throws OCRException {

		logger.info("Get Policies is Called");
		String query = null;
		Connection con = null;
		ResultSet rst = null;
		List<Policy> list = new ArrayList<Policy>();
		try {
			if (rollcode.equals("insured")) {
				con = DBUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(QueryMapper.getPolicyDetailsInsuredQuery);
				pstmt.setString(1, username);
				rst = pstmt.executeQuery();
			} else if (rollcode.equals("agent")) {

				con = DBUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(QueryMapper.getPolicyDetailsAgentQuery);
				pstmt.setString(1, username);
				rst = pstmt.executeQuery();
			} else {

				con = DBUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(QueryMapper.getPolicyDetailsAdminQuery);
				rst = pstmt.executeQuery();
			}

			while (rst.next()) {
				int policy_number = rst.getInt("policy_number");
				double policy_premium = rst.getDouble("policy_premium");
				Policy policy = new Policy(policy_number, policy_premium);
				list.add(policy);

			}

		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e.getMessage());
			throw new OCRException(e.getMessage());
		}

		return list;
	}

	@Override
	public List<Integer> getAccountDetails(String rollcode, String username) throws OCRException {

		logger.info("Get Account Details is Called");
		String query = null;
		Connection con = null;
		ResultSet rst = null;
		List<Integer> list = new ArrayList<Integer>();
		try {
			if (rollcode.equals("insured")) {
				con = DBUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(QueryMapper.getAccDetailsInsuredQuery);
				pstmt.setString(1, username);
				rst = pstmt.executeQuery();
			} else if (rollcode.equals("agent")) {

				con = DBUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(QueryMapper.getAccDetailsAgentQuery);
				pstmt.setString(1, username);
				rst = pstmt.executeQuery();
			} else {

				con = DBUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(QueryMapper.getAccDetailsAdminQuery);
				rst = pstmt.executeQuery();
			}

			while (rst.next()) {

				int account_number = rst.getInt("account_number");
				list.add(account_number);

			}
		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e.getMessage());
			throw new OCRException(e.getMessage());
		}
		return list;

	}

	@Override
	public List<QuestionDetails> getQA(String questionID) throws OCRException {

		List<QuestionDetails> list = new ArrayList<>();
		Connection con = null;
		logger.info("Get QA is Called");
		try {
			con = DBUtil.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.getQaQuery);
			pstmt.setString(1, questionID);
			ResultSet rst = pstmt.executeQuery();
			while (rst.next()) {
				list.add(new QuestionDetails(rst.getString(1), rst.getString(2), rst.getString(3), rst.getString(4),
						rst.getString(5)));

			}
		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e.getMessage());
			throw new OCRException(e.getMessage());
		}
		return list;
	}

	@Override
	public List<String> getAnswers(String questionID) throws OCRException {

		List<String> list = new ArrayList<>();
		logger.info("Get Answers is Called");
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.getAnswerQuery);
			pstmt.setString(1, questionID);
			ResultSet rst = pstmt.executeQuery();
			while (rst.next()) {
				list.add(rst.getString(1));
			}
		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e.getMessage());
			throw new OCRException(e.getMessage());
		}
		return list;
	}

	@Override
	public boolean createClaimAnswer(int claimNumber, int policynumber, int accountnumber, String questionId,
			String question, String answer) throws OCRException {
		// TODO Auto-generated method stub

		logger.info("Create Claim answer is Called");
		Connection con = null;
		try {

			con = DBUtil.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.claimAnswerInsQuery);
			pstmt.setInt(1, claimNumber);
			pstmt.setInt(2, policynumber);
			pstmt.setInt(3, accountnumber);
			pstmt.setString(4, questionId);
			pstmt.setString(5, question);
			pstmt.setString(6, answer);
			id = pstmt.executeUpdate();
			if (id == 1)
				return true;
			con.close();
		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e.getMessage());
			throw new OCRException(e.getMessage());
		}
		return false;
	}

	@Override
	public List<getQuestions> getQid(int policyNumber) throws OCRException {
		// TODO Auto-generated method stub
		logger.info("Get Qid is Called");
		List<getQuestions> list = new ArrayList<>();
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.getQidQuery);
			pstmt.setInt(1, policyNumber);
			ResultSet rst = pstmt.executeQuery();

			while (rst.next()) {
				list.add(new getQuestions(rst.getString(1), rst.getString(2), ""));

			}
		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e.getMessage());
			throw new OCRException(e.getMessage());
		}
		return list;
	}

	@Override
	public List<Claim> getClaim(int policyNumber, int claimId) throws OCRException {
		// TODO Auto-generated method stub

		logger.info("Get Claim is Called");
		List<Claim> list = new ArrayList<>();
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.getClaimQuery);
			pstmt.setInt(1, policyNumber);
			pstmt.setInt(2, claimId);
			ResultSet rst = pstmt.executeQuery();
			while (rst.next()) {
				list.add(new Claim(rst.getInt(1), rst.getString(2), rst.getString(3), rst.getString(4),
						rst.getString(5), rst.getInt(6), rst.getString(7), rst.getInt(8)));

			}
		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e.getMessage());
			throw new OCRException(e.getMessage());
		}
		return list;

	}

	@Override
	public List<ClaimAnswers> getClaimAnswer(int policyNumber, int claimId) throws OCRException {
		// TODO Auto-generated method stub
		logger.info("Get Claim answer is Called");
		List<ClaimAnswers> list = new ArrayList<>();
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.getClaimAnswerQuery);
			pstmt.setInt(1, policyNumber);
			pstmt.setInt(2, claimId);
			ResultSet rst = pstmt.executeQuery();
			while (rst.next()) {
				list.add(new ClaimAnswers(rst.getInt(1), rst.getInt(2), rst.getInt(3), rst.getString(4),
						rst.getString(5), rst.getString(6)));

			}
		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e.getMessage());
			throw new OCRException(e.getMessage());
		}
		return list;

	}

	@Override
	public List<ClaimAnswers> getPolicyNumberFromClaim() throws OCRException {
		logger.info("Get Policy from Claim is Called");
		List<ClaimAnswers> list = new ArrayList<>();
		Connection con = null;
		try {
			con = DBUtil.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.getPfromClaimQuery1);

			ResultSet rst = pstmt.executeQuery();
			while (rst.next()) {
				ClaimAnswers claimAns = new ClaimAnswers();
				claimAns.setClaimNumber(rst.getInt("claim_number"));
				claimAns.setPolicyNumber(rst.getInt("policy_number"));
				list.add(claimAns);

			}

		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e.getMessage());
			throw new OCRException(e.getMessage());
		}
		return list;
	}

	@Override
	public List<ClaimAnswers> getPolicyNumberFromClaim(String roleCode, String userName) throws OCRException {
		logger.info("Get Policy Number from Calim Called");
		List<ClaimAnswers> list = new ArrayList<>();
		Set<Integer> distinctAccSet = new HashSet<>(getAccountDetails(roleCode, userName));
		// Distinct values only

		Connection con = null;
		int account_number;
		for (Integer acc : distinctAccSet) {
			account_number = acc;
			try {
				con = DBUtil.getConnection();
				PreparedStatement pstmt = con.prepareStatement(QueryMapper.getPfromClaimQuery2);
				pstmt.setInt(1, account_number);
				ResultSet rst = pstmt.executeQuery();
				while (rst.next()) {
					ClaimAnswers claimAns = new ClaimAnswers();
					claimAns.setClaimNumber(rst.getInt("claim_number"));
					claimAns.setPolicyNumber(rst.getInt("policy_number"));
					list.add(claimAns);

				}

			} catch (ClassNotFoundException | SQLException e) {
				logger.error(e.getMessage());
				throw new OCRException(e.getMessage());
			}
		}
		return list;

	}

	@Override
	public int addTransaction(int policy_number, int account_number) throws OCRException {
		Connection con = null;
		int check = 0;
		logger.info("Add Transaction is Called");
		try {
			con = DBUtil.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.addTransactionQuery);
			pstmt.setInt(1, policy_number);
			pstmt.setInt(2, account_number);
			check = pstmt.executeUpdate();
			con.close();

		} catch (ClassNotFoundException | SQLException e) {
			logger.error(e.getMessage());
			throw new OCRException(e.getMessage());
		}
		return check;
	}

}
