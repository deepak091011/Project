package com.cg.service;

import java.util.List;

import com.cg.entity.Claim;
import com.cg.entity.ClaimAnswers;
import com.cg.entity.Policy;
import com.cg.entity.QuestionDetails;
import com.cg.entity.UserRole;
import com.cg.entity.getQuestions;
import com.cg.exception.OCRException;

public interface IOCRService {

	public String validateUserLogin(String username, String password) throws OCRException;

	public boolean createUser(UserRole userobj) throws OCRException;

	public int addClaim(Claim claim) throws OCRException;

	public List<Policy> getPolicies(String rollCode, String username) throws OCRException;

	public List<Integer> getAccountNumber(String rollcode, String username) throws OCRException;

	public List<ClaimAnswers> getClaimAnswer(int policyNumber, int claimId) throws OCRException;

	public List<QuestionDetails> getQA(String questionID) throws OCRException;

	public List<String> getAnswers(String questionID) throws OCRException;

	public List<getQuestions> getQid(int policyNumber) throws OCRException;

	public List<Claim> getClaim(int policyNumber, int claimId) throws OCRException;;

	public boolean createClaimAnswer(int claimNumber, int policynumber, int accountnumber, String questionId,
			String question, String answer) throws OCRException;

	public List<ClaimAnswers> getPolicyNumberFromClaim() throws OCRException;

	public List<ClaimAnswers> getPolicyNumberFromClaim(String roleCode, String userName)
			throws OCRException;
	
	public int addTransaction(int policynumber, int accountnumber) throws OCRException;
	
}
