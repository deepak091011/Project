package com.cg.service;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;

import com.cg.dao.IOCRDao;
import com.cg.dao.OCRDaoImpl;
import com.cg.entity.Claim;
import com.cg.entity.ClaimAnswers;
import com.cg.entity.Policy;
import com.cg.entity.QuestionDetails;
import com.cg.entity.UserRole;
import com.cg.entity.getQuestions;
import com.cg.exception.OCRException;

public class OCRServiceImpl implements IOCRService {

	IOCRDao dao = new OCRDaoImpl();

	@Override
	public String validateUserLogin(String username, String password) throws OCRException {
		// TODO Auto-generated method stub

		return dao.validateUserLogin(username, password);
	}

	@Override
	public boolean createUser(UserRole userobj) throws OCRException {
		return dao.createUser(userobj);
		// TODO Auto-generated method stub

	}

	@Override
	public int addClaim(Claim claim) throws OCRException {
		// TODO Auto-generated method stub
		return dao.addClaim(claim);
	}

	@Override
	public List<Policy> getPolicies(String rollCode, String username) throws OCRException {

		return dao.getPolicies(rollCode, username);
	}

	@Override
	public List<Integer> getAccountNumber(String rollcode, String username) throws OCRException {
		return dao.getAccountDetails(rollcode, username);
	}

	@Override
	public List<QuestionDetails> getQA(String questionID) throws OCRException {
		// TODO Auto-generated method stub
		return dao.getQA(questionID);
	}

	@Override
	public List<String> getAnswers(String questionID) throws OCRException {
		// TODO Auto-generated method stub
		return dao.getAnswers(questionID);
	}

	@Override
	public boolean createClaimAnswer(int claimNumber, int policynumber, int accountnumber, String questionId,
			String question, String answer) throws OCRException {
		// TODO Auto-generated method stub
		return dao.createClaimAnswer(claimNumber, policynumber, accountnumber, questionId, question, answer);

	}

	@Override
	public List<getQuestions> getQid(int policyNumber) throws OCRException {
		// TODO Auto-generated method stub
		return dao.getQid(policyNumber);
	}

	@Override
	public List<Claim> getClaim(int policyNumber, int claimId) throws OCRException {
		// TODO Auto-generated method stub
		return dao.getClaim(policyNumber, claimId);
	}

	@Override
	public List<ClaimAnswers> getClaimAnswer(int policyNumber, int claimId) throws OCRException {
		// TODO Auto-generated method stub
		return dao.getClaimAnswer(policyNumber, claimId);
	}

	@Override
	public List<ClaimAnswers> getPolicyNumberFromClaim() throws OCRException {
		// TODO Auto-generated method stub
		return dao.getPolicyNumberFromClaim();
	}

	@Override
	public List<ClaimAnswers> getPolicyNumberFromClaim(String roleCode, String userName) throws OCRException {
		// TODO Auto-generated method stub
		return dao.getPolicyNumberFromClaim(roleCode, userName);
	}

	@Override
	public int addTransaction(int policynumber, int accountnumber) throws OCRException {
		// TODO Auto-generated method stub
		return dao.addTransaction(policynumber, accountnumber);
	}

}
