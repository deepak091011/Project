package com.cg.testing;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.cg.dao.IOCRDao;
import com.cg.dao.OCRDaoImpl;
import com.cg.entity.ClaimAnswers;
import com.cg.entity.Policy;
import com.cg.entity.QuestionDetails;
import com.cg.entity.getQuestions;
import com.cg.exception.OCRException;

public class TestOCR {

	IOCRDao dao;

	@Test
	public void testValidateUserLogin1() {
		dao = new OCRDaoImpl();
		String result = null;
		try {
			result = dao.validateUserLogin("admin", "admin");
		} catch (OCRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals("admin", result);
	}

	@Test
	public void testValidateUserLogin2() {
		dao = new OCRDaoImpl();
		String result = null;
		try {
			result = dao.validateUserLogin("admin1", "admin");
		} catch (OCRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals(null, result);
	}

	@Test
	public void testGetPolicy1() {
		dao = new OCRDaoImpl();
		List<Policy> result = null;
		try {
			result = dao.getPolicies("admin", "admin");
		} catch (OCRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertNotNull(result);
	}

	@Test
	public void testGetAccountDetails() {
		dao = new OCRDaoImpl();
		List<Integer> result = null;
		try {
			result = dao.getAccountDetails("admin", "admin");
		} catch (OCRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertNotNull(result);
	}

	@Test
	public void testGetQA1() {
		dao = new OCRDaoImpl();
		List<QuestionDetails> result = null;
		try {
			result = dao.getQA("RES01");
		} catch (OCRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertNotNull(result);
	}

	@Test
	public void testGetQid1() {
		dao = new OCRDaoImpl();
		List<getQuestions> result = null;
		try {
			result = dao.getQid(1001);
		} catch (OCRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertNotNull(result);
	}

	@Test
	public void testGetPolicyNumberFromClaim1() {
		dao = new OCRDaoImpl();
		List<ClaimAnswers> result = null;
		;
		try {
			result = dao.getPolicyNumberFromClaim();
		} catch (OCRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertNotNull(result);
	}

	@Test(expected = OCRException.class)
	public void testGetPolicyNumberFromClaim2() throws OCRException {
		dao = new OCRDaoImpl();
		List<ClaimAnswers> result = null;

		result = dao.getPolicyNumberFromClaim("RES01", "admin");

		assertNotNull(result);
	}
}
